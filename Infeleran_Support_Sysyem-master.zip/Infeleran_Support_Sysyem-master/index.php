<html>

<head>
    <meta charset="utf-8">
    <title>Infelearn</title>
    <link rel="stylesheet" href="styles/index.css">
    <style>
        h1 {
            color: teal;
        }
    </style>
</head>

<body>
    <header>
        <div class="hed">
           
            <img class="box" src="logo.png">

            <div class="clearfix"></div>
            <nav class="Nav">

            </nav>
        </div>
        <div>
            <h2 style="margin: 25px; font-size: 45px; color:rgb(115, 115, 243);">.</h2>
        </div><br><br><br><br><br>
        <div class="mid">
            <a href="Login.php">Login</a>
        </div></br>
        <div class="mid">
            <a href="signup.php">Signup</a>
        </div><br><br><br><br><br>
    </header>
    <div class="txt">
         <h4><u>ABOUT OUR PROJECT</u></h4>
		<p>This project is about user's FAQ's platform. Where user can ask his doubts and also clarifies other user's doubts. By this process every student can improve his\her
		knowledge in there studies. And they can improve there skills by answering the questions. This platform contains four main parts.
		
		<ul style="list-style-type:disc;font-size:30px;">
			<li>Solved</li>
			<li>Unsolved</li>
			<li>Ask</li>
			<li>FAQ</li>
		</ul>  
		<h5><u>Solved:</u></h5>
		<p> In this solved section the user can get the answers of any questions and these questions are even divided into catagories. And also user can search a particular question.
		In this section we can see the answers in picture format also.</p> 
		
		<h5><u>Unsolved:</u></h5>
		<p> In this Unsolved section the user can solve other's questions. In this section there will be questions which are not solved and any user can solve it , if know the answer.
		And also user can add a picture or a document.
		
		<h5><u>Ask:</u></h5>
		In this section any user can upload his\her question. When user uploaded question then it will print the questionin Unsolved section. In this section user can also upload the picture or an document.
		
		<h5><u>FAQ:</u></h5>
		This section is  very commone in every website or app. In this section there are some inbulit question and answers about the website. So that user can find instant answer to his particular
		question. Even there is an 'ASK' option provided fo the  user, so that he can ask any question regarding website.

    </div>

    <div class="footer">

        <div class="cprit">Copyright &copy 2021 | All Rights Reserved <br><br> Prototype of Project
        </div>
</body>

</html>
